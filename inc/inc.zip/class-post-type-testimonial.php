<?php

namespace Blueprint\PostType;

class Testimonial extends PostType {

  function __construct($post_type) {
    parent::__construct($post_type);
  }

}
