<?php

// Add placeholder size
add_image_size('lowres',10,10,false);
add_image_size('hero',1600,800,true);
add_image_size('blog',700,400,true);
