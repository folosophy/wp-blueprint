<?php

function bp_get_social() {
  return get_field('main_social','option');
}
