<?php

namespace Blueprint\Acf;

class Field_SectionHalves {

  function __construct($name) {
    parent::constructor($name,'field_5972338fadc60');
  }

}
