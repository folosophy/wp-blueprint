<?php

namespace Blueprint\Field;

class SectionHalves extends Section {

  function __construct() {
    $this->addField();
  }

}
