<?php

namespace Blueprint\Acf;
use \Blueprint as bp;
use \Blueprint\Acf as acf;

class Field {

  use Builder;
  use bp\Chain;

  protected $name;
  protected $field = array();
  protected $hidden;
  protected $key;
  protected $logic;
  protected $prefix;
  protected $saveKeys;
  protected $saveValue;

  function __construct($key,$parent) {
    $this->parent = $parent;
    $this->setName($key);
    $this->setPrefix();
    $this->setLabel();
    $this->field['wrapper'] = array();
    $this->setRequired(true);
    if (method_exists($this,'init')) {$this->init();}
  }

  function addSaveKey($key,$table='post') {

    // Setup vars
    $save = array();
    if (!is_array($this->saveKeys)) {$this->saveKeys = array();}

    // Set table type
    $tables = array('post','option','user');
    if (!in_array($table,$tables)) {diedump('Field addSaveKey: invalid table');}
    $save['table'] = $table;

    // Add key
    $save['key'] = $key;

    array_push($this->saveKeys,$save);

    add_filter("acf/update_value/key=$this->key",array($this,'saveValue'));

    return $this;

  }

  function applyLoadFilters() {
    $tag = 'bp/load_field/key=' . $this->key;
    apply_filters($tag,$this);
  }

  function disable() {
    $this->field['disabled'] = true;
    return $this;
  }

  function dumpField() {
    diedump($this->field);
  }

  function getKey() {
    return $this->field['key'];
  }

  function getLogic() {
    if (!isset($this->logic)) {$this->setLogic();}
    return $this->logic;
  }

  function getName() {
    return $this->field['name'];
  }

  function getParentKey() {
    if (is_subclass_of($this->parent,'Blueprint\Acf\Field')) {
      return $this->parent->getKey();
    } else {
      return null;
    }
  }

  function getType() {
    return $this->field['type'];
  }

  function hideLabel() {
    $this->addClass('nolabel');
    return $this;
  }

  function setLogic($key=null,$value=null,$operator='==') {
    $logic = (new acf\Logic($this));
    $this->logic = $logic;
    if (isset($key)) {
      $logic->addCondition($key,$value,$operator);
      return $this;
    } else {
      return $logic;
    }
  }

  protected function setPrefix() {
    $parent = $this->parent;
    if (is_subclass_of($parent,'Blueprint\Acf\Field')) {
      $this->prefix = $parent->getKey() . '_';
    } else {
      $this->prefix = 'field_';
    }
  }

  function getPrefix() {
    return $this->prefix;
  }

  function saveValue($val) {
    if (is_array($this->saveKeys)) {
      foreach ($this->saveKeys as $save) {
        switch($save['table']) {
          case 'post' :
            $update = add_post_meta(get_the_ID(),$key,$val);
            break;
        }
        //$update = add_post_meta(get_the_ID(),$key,$val);
      }
    }
    return $val;
  }

  function setClass($class) {
    $this->field['wrapper']['class'] = $class;
    return $this;
  }

  function addClass($class) {
    if (!isset($this->field['wrapper']['class'])) {
      $this->field['wrapper']['class'] = '';
    }
    $this->field['wrapper']['class'] .= " $class ";
  }

  function setDefaultValue($value) {
    $this->field['default_value'] = $value;
    return $this;
  }

  function setInstructions($desc) {
    $this->field['instructions'] = $desc;
    return $this;
  }

   protected function setKey($key) {
    $key = $this->prefix . $key;
    $this->key = $key;
    $this->field['key'] = $key;
    return $this;
  }

  function setName($name) {
    $this->name = strtolower($name);
    $this->field['name']  = $name;
    $this->field['_name'] = $name;
    $this->setPrefix();
    $this->setKey($name);
    return $this;
  }

  function set_Name() {
    $this->field['_name'] = '_' . $this->getName();
  }

  function setLabel($label=null) {
    if (!$label) {$label = $this->name;}
    $label = ucwords(str_replace('_',' ',$label));
    $this->field['label'] = $label;
    return $this;
  }

  function setType($type) {
    $this->field['type'] = strtolower($type);
    return $this;
  }

  function setRequired($required=1) {
    if ($required) {$this->field['required'] = $required;}
    else {$this->field['required'] = 0;}
    return $this;
  }

  function setWidth($width) {
    $this->field['wrapper']['width'] = $width;
    return $this;
  }

  function getField() {
    if ($this->logic) {
      $this->field['conditional_logic'] = $this->logic->getConditions();
    }
    return $this->field;
  }

  function inputError($expects,$given=null) {
    wp_die(__FUNCTION__ . ' expects ' . $expects . '.');
  }

}
